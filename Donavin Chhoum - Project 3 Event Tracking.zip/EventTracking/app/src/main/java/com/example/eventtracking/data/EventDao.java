package com.example.eventtracking.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

// Reads and writes the events table - CRUD
public class EventDao {

    private final DatabaseHelper helper;

    public EventDao(Context context) {
        helper = new DatabaseHelper(context);
    }

    // Create: adds a new event to the database
    public void insert(Event event) {
        helper.getWritableDatabase().insert(DatabaseHelper.TABLE_EVENTS, null, toValues(event));
    }

    // Read: all of user's events, soonest first
    public List<Event> getUserEvents(long userId) {
        List<Event> events = new ArrayList<>();
        try (Cursor cursor = helper.getReadableDatabase().query(
                DatabaseHelper.TABLE_EVENTS, null,
                DatabaseHelper.EVENT_USER_ID + " = ?", new String[]{String.valueOf(userId)},
                null, null, DatabaseHelper.EVENT_DATE_TIME + " ASC")) {
            while (cursor.moveToNext()) {
                events.add(toEvent(cursor));
            }
        }
        return events;
    }

    // Read: one event by id, or null if it doesn't exist
    public Event getEventById(long eventId) {
        try (Cursor cursor = helper.getReadableDatabase().query(
                DatabaseHelper.TABLE_EVENTS, null,
                DatabaseHelper.EVENT_ID + " = ?", new String[]{String.valueOf(eventId)},
                null, null, null)) {
            return cursor.moveToFirst() ? toEvent(cursor) : null;
        }
    }

    // Update: changes an existing event. Reminder is reset because date may have changed
    public void update(Event event) {
        ContentValues values = toValues(event);
        values.put(DatabaseHelper.EVENT_REMINDER_SENT, 0);
        helper.getWritableDatabase().update(DatabaseHelper.TABLE_EVENTS, values,
                DatabaseHelper.EVENT_ID + " = ?", new String[]{String.valueOf(event.getId())});
    }

    // Delete: removes an event
    public void delete(long eventId) {
        helper.getWritableDatabase().delete(DatabaseHelper.TABLE_EVENTS,
                DatabaseHelper.EVENT_ID + " = ?", new String[]{String.valueOf(eventId)});
    }

    // Remembers that the SMS alert was sent so it isn't sent twice.
    public void markReminderSent(long eventId) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.EVENT_REMINDER_SENT, 1);
        helper.getWritableDatabase().update(DatabaseHelper.TABLE_EVENTS, values,
                DatabaseHelper.EVENT_ID + " = ?", new String[]{String.valueOf(eventId)});
    }

    // Converts an Event into database values
    private ContentValues toValues(Event event) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.EVENT_USER_ID, event.getUserId());
        values.put(DatabaseHelper.EVENT_NAME, event.getName());
        values.put(DatabaseHelper.EVENT_DATE_TIME, event.getDateTimeMillis());
        values.put(DatabaseHelper.EVENT_DESCRIPTION, event.getDescription());
        values.put(DatabaseHelper.EVENT_REMINDER_SENT, event.isReminderSent());
        return values;
    }

    // Converts the current database row into an Event
    private Event toEvent(Cursor cursor) {
        return new Event(
                cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_ID)),
                cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_USER_ID)),
                cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_NAME)),
                cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_DATE_TIME)),
                cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_DESCRIPTION)),
                cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_REMINDER_SENT)) == 1);
    }
}
