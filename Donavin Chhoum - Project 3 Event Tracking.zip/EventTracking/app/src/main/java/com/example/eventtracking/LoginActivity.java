package com.example.eventtracking;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.eventtracking.data.UserDao;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Objects;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText usernameInput;
    private TextInputEditText passwordInput;
    private UserDao userDao;
    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        session = new SessionManager(this);
        long savedUserId = session.getUserId();
        if (savedUserId != UserDao.NOT_FOUND) {
            startActivity(new Intent(this, EventsActivity.class)
                    .putExtra("userId", savedUserId));
            finish();
            return; // don't build the login screen
        }

        setContentView(R.layout.activity_login);

        userDao = new UserDao(this);
        usernameInput = findViewById(R.id.login_username);
        passwordInput = findViewById(R.id.login_password);

        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);
        loginButton.setOnClickListener(v -> login());
        createAccountButton.setOnClickListener(v -> createAccount());
    }

    // Checks username and password against database
    private void login() {
        String username = Objects.requireNonNull(usernameInput.getText()).toString().trim();
        String password = Objects.requireNonNull(passwordInput.getText()).toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            showMessage(R.string.error_fill_in_fields);
            return;
        }

        long userId = userDao.login(username, password);
        if (userId == UserDao.NOT_FOUND) {
            showMessage(R.string.error_invalid_credentials);
        } else {
            openSmsScreen(userId);
        }
    }

    // Saves a new username and password to the database, then logs the new user in
    private void createAccount() {
        String username = Objects.requireNonNull(usernameInput.getText()).toString().trim();
        String password = Objects.requireNonNull(passwordInput.getText()).toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            showMessage(R.string.error_fill_in_fields);
            return;
        }

        if (userDao.usernameExists(username)) {
            showMessage(R.string.error_username_taken);
            return;
        }

        long userId = userDao.createUser(username, password);
        openSmsScreen(userId);
    }

    private void openSmsScreen(long userId) {
        session.saveUser(userId);
        startActivity(new Intent(this, SmsNotificationActivity.class).putExtra("userId", userId));
        finish();
    }

    private void showMessage(int messageId) {
        Toast.makeText(this, messageId, Toast.LENGTH_SHORT).show();
    }
}
