package com.example.eventtracking;

import android.Manifest;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.example.eventtracking.data.UserDao;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Objects;

public class SmsNotificationActivity extends AppCompatActivity {

    private long userId;
    private UserDao userDao;
    private View permissionCard;
    private View deniedCard;
    private MaterialSwitch alertSwitch;
    private TextInputEditText phoneInput;

    private final ActivityResultLauncher<String> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                updateScreen();
                if (!granted) {
                    deniedCard.setVisibility(View.VISIBLE);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notification);

        userId = getIntent().getLongExtra("userId", UserDao.NOT_FOUND);
        userDao = new UserDao(this);
        permissionCard = findViewById(R.id.permissionCard);
        deniedCard = findViewById(R.id.deniedCard);
        alertSwitch = findViewById(R.id.eventReminderSwitch);
        phoneInput = findViewById(R.id.phoneNumberInput);

        // Show the settings this user saved last time.
        alertSwitch.setChecked(userDao.isSmsEnabled(userId));
        phoneInput.setText(userDao.getPhoneNumber(userId));

        Button allowButton = findViewById(R.id.allowSmsButton);
        Button notNowButton = findViewById(R.id.notNowButton);
        Button continueButton = findViewById(R.id.continueButton);
        allowButton.setOnClickListener(v -> permissionLauncher.launch(Manifest.permission.SEND_SMS));
        notNowButton.setOnClickListener(v -> openEventsScreen());
        continueButton.setOnClickListener(v -> {
            userDao.saveSmsSettings(userId, Objects.requireNonNull(phoneInput.getText()).toString().trim(), alertSwitch.isChecked());
            openEventsScreen();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateScreen();
    }

    private void updateScreen() {
        boolean granted = SmsHelper.hasPermission(this);
        permissionCard.setVisibility(granted ? View.GONE : View.VISIBLE);
        alertSwitch.setEnabled(granted);
        phoneInput.setEnabled(granted);
        if (!granted) {
            alertSwitch.setChecked(false);
        }
    }

    private void openEventsScreen() {
        startActivity(new Intent(this, EventsActivity.class).putExtra("userId", userId));
        finish();
    }
}
