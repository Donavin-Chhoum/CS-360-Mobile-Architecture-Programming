package com.example.eventtracking;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.eventtracking.data.Event;
import com.example.eventtracking.data.EventDao;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

// Main screen. Shows user's events in a grid and lets them add, edit, and delete events.
public class EventsActivity extends AppCompatActivity {

    private long userId;
    private EventDao eventDao;
    private EventAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        userId = getIntent().getLongExtra("userId", -1L);
        eventDao = new EventDao(this);

        // Set up the grid. The number of columns is set in res/values/integers.xml.
        adapter = new EventAdapter(new EventAdapter.EventClickListener() {
            @Override
            public void onEditClick(Event event) {
                openEventForm(event.getId());
            }

            @Override
            public void onDeleteClick(Event event) {
                eventDao.delete(event.getId());
                loadEvents();
            }
        });

        RecyclerView grid = findViewById(R.id.eventsRecyclerView);
        int columns = getResources().getInteger(R.integer.event_grid_columns);
        GridLayoutManager layoutManager = new GridLayoutManager(this, columns);
        layoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                return adapter.isHeader(position) ? columns : 1;
            }
        });
        grid.setLayoutManager(layoutManager);
        grid.setAdapter(adapter);

        FloatingActionButton addButton = findViewById(R.id.addEventFab);
        Button logoutButton = findViewById(R.id.logout_button);
        addButton.setOnClickListener(v -> openEventForm(-1L));
        logoutButton.setOnClickListener(v -> {
            new SessionManager(this).clear();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadEvents();
    }

    // Reads user's events from database and shows them
    private void loadEvents() {
        List<Event> events = eventDao.getUserEvents((userId));
        adapter.setEvents(events);

        // Text user about any upcoming events starting soon
        SmsHelper.sendUpcomingEventAlerts(this, userId, events);
    }

    private void openEventForm(long eventId) {
        startActivity(new Intent(this, AddEditEventActivity.class)
                .putExtra("userId", userId)
                .putExtra("eventId", eventId));
    }
}
