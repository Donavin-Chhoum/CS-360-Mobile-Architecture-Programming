package com.example.eventtracking;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

import com.example.eventtracking.data.Event;
import com.example.eventtracking.data.EventDao;
import com.example.eventtracking.data.UserDao;

import java.util.List;

// Helper class to send SMS alerts
public class SmsHelper {
    private static final long ONE_DAY_MILLIS = 24L * 60 * 60 * 1000;

    private SmsHelper() { }

    // True if user has allowed the app to send SMS messages
    public static boolean hasPermission(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    public static void sendUpcomingEventAlerts(Context context, long userId, List<Event> events) {
        UserDao userDao = new UserDao(context);
        String phoneNumber = userDao.getPhoneNumber(userId);
        if (!hasPermission(context) || !userDao.isSmsEnabled(userId) || phoneNumber.isEmpty()) {
            return; // No permissions, alerts switched off, or no phone number provided = skip
        }

        EventDao eventDao = new EventDao(context);
        long now = System.currentTimeMillis();
        for (Event event : events) {
            boolean startsSoon = event.getDateTimeMillis() > now && event.getDateTimeMillis() <= now + ONE_DAY_MILLIS;

            if (startsSoon && !event.isReminderSent()) {
                String message = context.getString(R.string.event_reminder_message,
                        event.getName(), event.getFormattedDate(), event.getFormattedTime());

                if(sendMessage(context, phoneNumber, message)) {
                    eventDao.markReminderSent(event.getId());
                }
            }
        }
    }

    private static boolean sendMessage(Context context, String phoneNumber, String message) {
        try {
            SmsManager smsManager = context.getSystemService((SmsManager.class));
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            return true;
        } catch (SecurityException | IllegalArgumentException | NullPointerException e) {
            return false;
        }
    }
}
