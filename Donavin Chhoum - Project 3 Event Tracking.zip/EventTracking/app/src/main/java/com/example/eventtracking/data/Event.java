package com.example.eventtracking.data;

import java.text.DateFormat;
import java.util.Date;

// Creation of scheduled event belonging to one user.
public class Event {

    private final long id;
    private final long userId;
    private final String name;
    private final long dateTimeMillis;
    private final String description;
    private final boolean reminderSent;

    public Event(long id, long userId, String name, long dateTimeMillis, String description, boolean reminderSent) {
        this.id = id;
        this.userId = userId;
        this.name = name;
        this.dateTimeMillis = dateTimeMillis;
        this.description = description;
        this.reminderSent = reminderSent;
    }

    public long getId() {
        return id;
    }

    public long getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public long getDateTimeMillis() {
        return dateTimeMillis;
    }

    public String getDescription() {
        return description;
    }

    public boolean isReminderSent() {
        return reminderSent;
    }

    // Time only, for the card (the date appears in the header)
    public String getFormattedTime() {
        return DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(dateTimeMillis));
    }

    // Date only, for the header
    public String getFormattedDate() {
        return new java.text.SimpleDateFormat("EEEE, MMM d", java.util.Locale.getDefault())
                .format(new Date(dateTimeMillis));
    }

}
