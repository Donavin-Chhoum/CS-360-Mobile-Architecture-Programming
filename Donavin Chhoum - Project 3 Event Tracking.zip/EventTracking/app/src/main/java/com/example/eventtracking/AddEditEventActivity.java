package com.example.eventtracking;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.eventtracking.data.Event;
import com.example.eventtracking.data.EventDao;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Objects;

public class AddEditEventActivity extends AppCompatActivity {

    private long userId;
    private long eventId;

    // Holds the date and time the user picks.
    private final Calendar selected = Calendar.getInstance();
    private boolean dateChosen = false;
    private boolean timeChosen = false;

    private TextInputEditText nameInput;
    private TextInputEditText dateInput;
    private TextInputEditText timeInput;
    private TextInputEditText descriptionInput;
    private EventDao eventDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_event);

        userId = getIntent().getLongExtra("userId", -1L);
        eventId = getIntent().getLongExtra("eventId", -1L);
        eventDao = new EventDao(this);

        nameInput = findViewById(R.id.eventNameInput);
        dateInput = findViewById(R.id.eventDateInput);
        timeInput = findViewById(R.id.eventTimeInput);
        descriptionInput = findViewById(R.id.eventDescriptionInput);

        // Tapping a date or time field opens a picker
        TextInputLayout dateLayout = findViewById(R.id.eventDateLayout);
        TextInputLayout timeLayout = findViewById(R.id.eventTimeLayout);
        dateInput.setOnClickListener(v -> showDatePicker());
        dateLayout.setEndIconOnClickListener(v -> showDatePicker());
        timeInput.setOnClickListener(v -> showTimePicker());
        timeLayout.setEndIconOnClickListener(v -> showTimePicker());

        Button cancelButton = findViewById(R.id.cancelButton);
        Button saveButton = findViewById(R.id.saveButton);
        cancelButton.setOnClickListener(v -> finish());
        saveButton.setOnClickListener(v -> saveEvent());

        if (eventId != -1L) {
            TextView title = findViewById(R.id.headerTitle);
            title.setText(R.string.edit_event);
            showExistingEvent();
        }
    }

    private void showExistingEvent() {
        Event event = eventDao.getEventById(eventId);
        nameInput.setText(event.getName());
        descriptionInput.setText(event.getDescription());

        selected.setTimeInMillis(event.getDateTimeMillis());
        dateChosen = true;
        timeChosen = true;
        showSelectedDate();
        showSelectedTime();
    }

    private void showDatePicker() {
        new DatePickerDialog(this, (picker, year, month, day) -> {
            selected.set(year, month, day);
            dateChosen = true;
            showSelectedDate();
        }, selected.get(Calendar.YEAR), selected.get(Calendar.MONTH),
                selected.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void showTimePicker() {
        boolean use24Hour = android.text.format.DateFormat.is24HourFormat(this);
        new TimePickerDialog(this, (picker, hour, minute) -> {
            selected.set(Calendar.HOUR_OF_DAY, hour);
            selected.set(Calendar.MINUTE, minute);
            timeChosen = true;
            showSelectedTime();
        }, selected.get(Calendar.HOUR_OF_DAY), selected.get(Calendar.MINUTE), use24Hour).show();
    }

    private void showSelectedDate() {
        dateInput.setText(DateFormat.getDateInstance(DateFormat.MEDIUM).format(selected.getTime()));
    }

    private void showSelectedTime() {
        timeInput.setText(DateFormat.getTimeInstance(DateFormat.SHORT).format(selected.getTime()));
    }

    // saves a new event or the changes to an existing one
    private void saveEvent() {
        String name = Objects.requireNonNull(nameInput.getText()).toString().trim();
        if (name.isEmpty() || !dateChosen || !timeChosen) {
            Toast.makeText(this, R.string.error_fill_in_fields_add_edit_event, Toast.LENGTH_SHORT).show();
            return;
        }

        selected.set(Calendar.SECOND, 0);
        selected.set(Calendar.MILLISECOND, 0);
        boolean isNewEvent = eventId == -1L;
        Event event = new Event(
                isNewEvent ? 0 : eventId,
                userId,
                name,
                selected.getTimeInMillis(), Objects.requireNonNull(descriptionInput.getText()).toString().trim(),
                false);

        if (isNewEvent) {
            eventDao.insert(event);
        } else {
            eventDao.update(event);
        }
        finish();
    }
}
