package com.example.eventtracking;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.eventtracking.data.Event;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

// Fills event grid with one card per event
public class EventAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{

    public interface EventClickListener {
        void onEditClick(Event event);
        void onDeleteClick(Event event);
    }

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_EVENT = 1;

    private final EventClickListener listener;
    // Each item is either a String (date header) or an Event
    private final List<Object> items = new ArrayList<>();
    // IDs of events whose description is showing
    private final Set<Long> expandedIds = new HashSet<>();

    public EventAdapter(EventClickListener listener) {
        this.listener = listener;
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setEvents(List<Event> events) {
        items.clear();
        SimpleDateFormat dayKey = new SimpleDateFormat("yyyyMMdd", Locale.US);
        String lastDay = null;
        for (Event event : events) {
            String day = dayKey.format(new Date(event.getDateTimeMillis()));
            if (!day.equals(lastDay)) {
                items.add(event.getFormattedDate());
                lastDay = day;
            }
            items.add(event);
        }
        notifyDataSetChanged();
    }

    // Lets the grid make headers span every column
    public boolean isHeader(int position) {
        return getItemViewType(position) == TYPE_HEADER;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        if (viewType == TYPE_HEADER) {
            return new HeaderViewHolder(inflater.inflate(R.layout.item_date_header, parent, false));
        }
        return new EventViewHolder(inflater.inflate(R.layout.item_event, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof HeaderViewHolder) {
            ((HeaderViewHolder) holder).text.setText((String) items.get(position));
            return;
        }

        EventViewHolder h = (EventViewHolder) holder;
        Event event = (Event) items.get(position);
        h.nameText.setText(event.getName());
        h.timeText.setText(event.getFormattedTime());
        h.editButton.setOnClickListener(v -> listener.onEditClick(event));
        h.deleteButton.setOnClickListener(v -> listener.onDeleteClick(event));

        // Description shows or hides when the card is tapped
        String description = event.getDescription().isEmpty()
                ? h.itemView.getContext().getString(R.string.no_description)
                : event.getDescription();
        h.descriptionText.setText(description);
        h.descriptionText.setVisibility(expandedIds.contains(event.getId()) ? View.VISIBLE : View.GONE);

        h.itemView.setOnClickListener(v -> {
            if (!expandedIds.remove(event.getId())) {
                expandedIds.add(event.getId());
            }
            notifyItemChanged(h.getBindingAdapterPosition());
        });
    }

    @Override
    public int getItemViewType(int position) {
        return items.get(position) instanceof String ? TYPE_HEADER : TYPE_EVENT;
    }



    @Override
    public int getItemCount() {
        return items.size();
    }

    static class HeaderViewHolder extends RecyclerView.ViewHolder {
        final TextView text;

        HeaderViewHolder(View view) {
            super(view);
            text = (TextView) view;
        }
    }

    // Holds the views of one event card
    public static class EventViewHolder extends RecyclerView.ViewHolder {
        final TextView nameText;
        final TextView timeText;
        final TextView descriptionText;
        final ImageButton editButton;
        final ImageButton deleteButton;

        EventViewHolder(View card) {
            super(card);
            nameText = card.findViewById(R.id.eventName);
            timeText = card.findViewById(R.id.eventTime);
            descriptionText = card.findViewById(R.id.eventDescription);
            editButton = card.findViewById(R.id.editButton);
            deleteButton = card.findViewById(R.id.deleteButton);
        }
    }
}
