package com.example.eventtracking;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.eventtracking.data.UserDao;

public class SessionManager {

    private static final String PREFS_NAME = "session";
    private static final String KEY_USER_ID = "userId";

    private final SharedPreferences prefs;

    public SessionManager(Context context) {
        prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public void saveUser(long userId) {
        prefs.edit().putLong(KEY_USER_ID, userId).apply();
    }

    // Returns the saved user's id, or UserDao.NOT_FOUND if nobody is logged in
    public long getUserId() {
        return prefs.getLong(KEY_USER_ID, UserDao.NOT_FOUND);
    }

    public void clear() {
        prefs.edit().remove(KEY_USER_ID).apply();
    }
}
