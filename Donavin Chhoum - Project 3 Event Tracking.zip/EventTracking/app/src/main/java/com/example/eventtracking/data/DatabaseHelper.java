package com.example.eventtracking.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/*
* Two Tables:
*  - users
*  - events
*/
public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "event_tracking.db";
    private static final int DATABASE_VERSION = 1;

    // users table
    public static final String TABLE_USERS = "users";
    public static final String USER_ID = "_id";
    public static final String USER_USERNAME = "username";
    public static final String USER_PASSWORD = "password";
    public static final String USER_PHONE = "phone_number";
    public static final String USER_SMS_ENABLED = "sms_enabled";

    // events table
    public static final String TABLE_EVENTS = "events";
    public static final String EVENT_ID = "_id";
    public static final String EVENT_USER_ID = "user_id";
    public static final String EVENT_NAME = "name";
    public static final String EVENT_DATE_TIME = "event_date_time";
    public static final String EVENT_DESCRIPTION = "description";
    public static final String EVENT_REMINDER_SENT = "reminder_sent";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + USER_USERNAME + " TEXT NOT NULL UNIQUE COLLATE NOCASE, "
                + USER_PASSWORD + " TEXT NOT NULL, "
                + USER_PHONE + " TEXT NOT NULL DEFAULT '', "
                + USER_SMS_ENABLED + " INTEGER NOT NULL DEFAULT 0)");

        db.execSQL("CREATE TABLE " + TABLE_EVENTS + " ("
                + EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + EVENT_USER_ID + " INTEGER NOT NULL, "
                + EVENT_NAME + " TEXT NOT NULL, "
                + EVENT_DATE_TIME + " INTEGER NOT NULL, "
                + EVENT_DESCRIPTION + " TEXT NOT NULL DEFAULT '', "
                + EVENT_REMINDER_SENT + " INTEGER NOT NULL DEFAULT 0)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Initial App Version (Version 1). Nothing to upgrade yet.

    }
}

