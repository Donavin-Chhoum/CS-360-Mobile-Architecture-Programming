package com.example.eventtracking.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

// Reads and writes the users table: login, new accounts, SMS settings
public class UserDao {

    // Sentinel value for no user.
    public static final long NOT_FOUND = -1L;

    private final DatabaseHelper helper;

    public UserDao(Context context) {
        helper = new DatabaseHelper(context);
    }

    // Queries the username and password. Return's user's id, or NOT_FOUND if they don't match
    public long login(String username, String password) {
        try (Cursor cursor = helper.getReadableDatabase().query(
                DatabaseHelper.TABLE_USERS, new String[]{DatabaseHelper.USER_ID},
                DatabaseHelper.USER_USERNAME + " = ? AND " + DatabaseHelper.USER_PASSWORD + " = ?",
                new String[]{username, password}, null, null, null)) {
            return cursor.moveToFirst() ? cursor.getLong(0) : NOT_FOUND;
        }
    }

    // Queries if an account with this username already exists
    public boolean usernameExists(String username) {
        try (Cursor cursor = helper.getReadableDatabase().query(
                DatabaseHelper.TABLE_USERS, new String[]{DatabaseHelper.USER_ID},
                DatabaseHelper.USER_USERNAME + " = ?", new String[]{username},
                null, null, null)) {
            return cursor.moveToFirst();
        }
    }

    public long createUser(String username, String password) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.USER_USERNAME, username);
        values.put(DatabaseHelper.USER_PASSWORD, password);
        return helper.getWritableDatabase().insert(DatabaseHelper.TABLE_USERS, null, values);
    }

    public void saveSmsSettings(long userId, String phoneNumber, boolean smsEnabled) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.USER_PHONE, phoneNumber);
        values.put(DatabaseHelper.USER_SMS_ENABLED, smsEnabled ? 1 : 0);
        SQLiteDatabase db = helper.getWritableDatabase();
        db.update(DatabaseHelper.TABLE_USERS, values,
                DatabaseHelper.USER_ID + " = ?", new String[]{String.valueOf(userId)});
    }

    public String getPhoneNumber(long userId) {
        return readColumn(userId, DatabaseHelper.USER_PHONE);
    }

    public boolean isSmsEnabled(long userId) {
        return readColumn(userId, DatabaseHelper.USER_SMS_ENABLED).equals("1");
    }

    // Reads one column of one user's row as text (empty if the user isn't found).
    private String readColumn(long userId, String column) {
        try (Cursor cursor = helper.getReadableDatabase().query(
                DatabaseHelper.TABLE_USERS, new String[]{column},
                DatabaseHelper.USER_ID + " = ?", new String[]{String.valueOf(userId)},
                null, null, null)) {
            return cursor.moveToFirst() ? cursor.getString(0) : "";
        }
    }

}
